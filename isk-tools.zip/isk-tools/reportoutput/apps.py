from django.apps import AppConfig


class ReportoutputConfig(AppConfig):
    name = 'reportoutput'
