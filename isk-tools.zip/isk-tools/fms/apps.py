from django.apps import AppConfig


class FmsConfig(AppConfig):
    name = 'fms'
