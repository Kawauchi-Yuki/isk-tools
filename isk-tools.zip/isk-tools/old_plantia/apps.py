from django.apps import AppConfig


class PlantiaConfig(AppConfig):
    name = 'old_plantia'
