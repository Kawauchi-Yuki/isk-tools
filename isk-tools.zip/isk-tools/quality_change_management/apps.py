from django.apps import AppConfig


class QualityChangeManagementConfig(AppConfig):
    name = 'quality_change_management'
