from django.apps import AppConfig


class IcimsConfig(AppConfig):
    name = 'icims'
