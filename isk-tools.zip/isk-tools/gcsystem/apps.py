from django.apps import AppConfig


class GcsystemConfig(AppConfig):
    name = 'gcsystem'
