from django.apps import AppConfig


class CpexcelConfig(AppConfig):
    name = 'cpexcel'
