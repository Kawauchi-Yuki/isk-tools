from django.apps import AppConfig


class NewPlantiaConfig(AppConfig):
    name = 'plantia'
